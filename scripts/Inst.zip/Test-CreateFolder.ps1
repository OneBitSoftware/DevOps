 # Create the install folder
"1111p2222q3333".Split('pq')
New-Item -ItemType Directory -Path "C:\Install\Test\T123"
